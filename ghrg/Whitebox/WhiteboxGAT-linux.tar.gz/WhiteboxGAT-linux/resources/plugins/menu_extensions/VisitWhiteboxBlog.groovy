import java.net.URI

def parentMenu = "Help"
def menuLabel = "Visit the Whitebox Blog"

java.awt.Desktop.getDesktop().browse(new URI("http://whiteboxgeospatial.wordpress.com"))